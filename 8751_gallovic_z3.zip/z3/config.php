<?php

return [
    "host"			=>	"localhost",
    "username"		=>	"root",
    "password"		=>	"lostebif",
    "db_name"		=>	"iiadb_z3"
];
