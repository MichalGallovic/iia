<?php
date_default_timezone_set('Europe/Bratislava');
$date = date('m/d/Y h:i:s a', time());

var_dump($date);