<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<img src="bar2013.php" alt="">
	<img src="bar2014.php" alt="">
</body>
</html>